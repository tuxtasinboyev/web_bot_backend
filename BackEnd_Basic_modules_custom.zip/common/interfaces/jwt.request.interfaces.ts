export interface ResponseJwtType {
  accessToken: string;
  refreshToken: string;
}
