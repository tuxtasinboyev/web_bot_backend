import { CourseLevelArr, HomeWorkSubStatusArr } from "./enum.types";

export const categoryApiBody = {
  schema: {
    type: 'object',
    properties: {
      name: { type: "string" },
      image: {
        type: 'string',
        format: 'binary',
      },
    }
  }
}

export const AdditionalApiBody = {
  schema: {
    type: 'object',
    properties: {
      propertyId: {
        type: 'string',
        format: 'uuid',
        example: 'cbd07e5b-0f70-4a9d-91f0-515d2f6e9999',
      },
      buildTypeId: {
        type: 'string',
        format: 'uuid',
        example: 'a1b2c3d4-e5f6-7890-1234-56789abcdef0',
      },
      label: {
        type: 'string',
        example: 'Modern House',
      },
      material: {
        type: 'string',
        example: 'Brick',
      },
      rooms: {
        type: 'integer',
        example: 4,
      },
      beds: {
        type: 'integer',
        example: 3,
      },
      baths: {
        type: 'integer',
        example: 2,
      },
      garages: {
        type: 'integer',
        example: 1,
      },
      garageSize: {
        type: 'number',
        example: 20.5,
      },
      year_build: {
        type: 'integer',
        example: 2015,
      },
      homeArea: {
        type: 'integer',
        example: 180,
      },
      lotDimensions: {
        type: 'string',
        example: '20x40',
      },
      lotArea: {
        type: 'integer',
        example: 800,
      },
      property_typeId: {
        type: 'string',
        format: 'uuid',
        example: '123e4567-e89b-12d3-a456-426614174000',
      },
    },
    required: [
      'propertyId',
      'buildTypeId',
      'label',
      'material',
      'rooms',
      'beds',
      'baths',
      'garages',
      'garageSize',
      'year_build',
      'homeArea',
      'lotDimensions',
      'lotArea',
      'property_typeId',
    ],
  },
};




export const userApiBody = {
  schema: {
    type: 'object',
    properties: {
      fullName: { type: "string" },
      email: { type: "string" },
      password: { type: "string" },
      image: {
        type: 'string',
        format: 'binary',
      },
    },
  },
};

// @ApiBody({
//   schema: {
//     type: 'object',
//     properties: {
//       name: { type: 'string' },
//       about: { type: 'string' },
//       price: { type: 'number' },
//       categoryId: { type: 'string' },
//       mentorId: { type: 'string' },
//       published: { type: 'boolean' },
//       banner: {
//         type: 'string',
//         format: 'binary',
//       },
//       introVideo: {
//         type: 'string',
//         format: 'binary',
//       },
//     },
//   },
// })
