export enum UserRoles {
  ADMIN = 'ADMIN',
  USER = 'USER',
}
