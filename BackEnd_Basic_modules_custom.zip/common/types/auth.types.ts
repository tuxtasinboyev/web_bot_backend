

export const MODEL_NAME = 'modelname';
export const IS_PUBLIC_KEY = 'isPublic';
export const ROLE_NAME = 'roles';
