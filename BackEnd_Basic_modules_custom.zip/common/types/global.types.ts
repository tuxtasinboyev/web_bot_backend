export enum ModelsEnum {
      BuildType = "buildType",
      USERS = "user",
      Category = "category",
      PROPERTIES = "property",
      Additional = "additional",
      PropertyMedia = "propertyMedia",
      CONTACT = "contact",
      TOUR = "tour",
      REVIW = "reviw",
      OAuthAccount = "oAuthAccount"
    }

export enum ModelsEnumInPrisma {
      BuildType = "buildType",
      USERS = "user",
      Category = "category",
      PROPERTIES = "property",
      Additional = "additional",
      PropertyMedia = "propertyMedia",
      CONTACT = "contact",
      TOUR = "tour",
      REVIW = "reviw",
      OAuthAccount = "oAuthAccount"
    }

